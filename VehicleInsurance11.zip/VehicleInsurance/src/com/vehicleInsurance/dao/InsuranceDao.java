package com.vehicleInsurance.dao;

import java.util.List;

import com.vehicleInsurance.model.ClaimedInsurance;
import com.vehicleInsurance.model.Customer;
import com.vehicleInsurance.model.Insurance;

public interface InsuranceDao {

	public Insurance buyInsurance(Insurance insurance);
	
	public int verifyUser(String username, String password);
	

	public List<Customer> getCustomer(int userid);
	
	public boolean claimInsurance(ClaimedInsurance claimins);
	
	public int verifyAdmin(String username, String password);
	
	public List<ClaimedInsurance> getPendingClaim();
	
	public List<Insurance> getInsurancedetails(int insuranceid);
	
	public int setRequestStatusAccept(String insuranceid);
	
	public int setRequestStatusReject(String insuranceid);
	
	public List<ClaimedInsurance> claimHistory(int userid);
	
	public void register(Customer cust);
	
}
