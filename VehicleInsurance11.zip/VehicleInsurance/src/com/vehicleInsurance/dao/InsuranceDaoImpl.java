package com.vehicleInsurance.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vehicleInsurance.model.ClaimedInsurance;
import com.vehicleInsurance.model.Customer;
import com.vehicleInsurance.model.Insurance;

@Repository
public class InsuranceDaoImpl implements InsuranceDao{

	//Declaring transaction interface reference
		static Transaction tx ;
	//Declaring sessionFactory interface reference
		private SessionFactory sessionFactory;
		
		@Autowired 
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}
		
		
	    @Override
	    public Insurance buyInsurance(Insurance insurance) {
		
		Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(insurance);
		tx.commit();
		return insurance;
		
	}


		@Override
		public int verifyUser(String username, String password) {
			Session session = this.sessionFactory.openSession();
			//query to check if user exists or not
			String query="From Customer a where a.username = :username and a.password = :password";
			Query q=session.createQuery(query);
			q.setString("username", username);
			q.setString("password", password);
		
			List<Customer> list = q.list();
		
		  //if no user exists with given username and password then list size wil	q.setString("username", username);l be 0
			if(list.size()==0)
			{
			return 0;
			}
			session.close();
			System.out.println(list.get(0).getCustomerId());
			return list.get(0).getCustomerId();
			
		}


		@Override
		public List<Customer> getCustomer(int userid) {
			Session session = this.sessionFactory.openSession();
			String query="From Customer a where a.customerId = :userid";
			Query q=session.createQuery(query);
			q.setInteger("userid", userid);
			
			List<Customer> list=q.list(); 
		    
		    session.close();
			return list;
		}


		@Override
		public boolean claimInsurance(ClaimedInsurance claimins) {
			int insuranceid=0;
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			System.out.println("dao of claim"+claimins);
			
				session.save(claimins);
				tx.commit();
				return true;
				
		
	
			
		}


		@Override
		public int verifyAdmin(String username, String password) {
			if(username.contentEquals("admin")&&password.contentEquals("admin"))
				
			{
				return 1;
			}
			return 0;
		}


		@Override
		public List<ClaimedInsurance> getPendingClaim() {
			Session session = this.sessionFactory.openSession();
			//query to check if user exists or not
			String query="From ClaimedInsurance";
			Query q=session.createQuery(query);
		
		
			List<ClaimedInsurance> list = q.list();
		
			return list;
		}


		@Override
		public List<Insurance> getInsurancedetails(int insuranceid) {
			Session session = this.sessionFactory.openSession();
			//query to check if user exists or not
			String query="From Insurance a where a.insuranceId = :insuranceId";
			Query q=session.createQuery(query);
			q.setInteger("insuranceId", insuranceid);
		
		
			List<Insurance> list = q.list();
		
			return list;
		}


		@Override
		public int setRequestStatusAccept(String insuranceid) {
			Session session = this.sessionFactory.openSession();
			//query to check if user exists or not
			String query="update ClaimedInsurance a  set a.status='Approved' where a.insuranceId = :insuranceId";
			Query q=session.createQuery(query);
			q.setString("insuranceId", insuranceid);
		int count=q.executeUpdate();
			return count;
		}


		@Override
		public int setRequestStatusReject(String insuranceid) {
			Session session = this.sessionFactory.openSession();
			//query to check if user exists or not
			String query="update ClaimedInsurance a  set a.status='Rejected' where a.insuranceId = :insuranceId";
			Query q=session.createQuery(query);
			q.setString("insuranceId", insuranceid);
		int count=q.executeUpdate();
			return count;
		}


		@Override
		public List<ClaimedInsurance> claimHistory(int userid) {
			
			Session session = this.sessionFactory.openSession();
			System.out.println("insideeeeeeeee");
			String query="From Insurance a where a.customerId =:userid";
			Query q=session.createQuery(query);
			q.setInteger("userid", userid);
			
			List<Insurance> list=q.list(); 
			
			int insuranceid=list.get(0).getInsuranceId();
			String query1="From ClaimedInsurance a where a.insuranceId = :insuranceid";
			
			Query q1=session.createQuery(query1);
			q1.setInteger("insuranceid", insuranceid);
			List<ClaimedInsurance> list1=q1.list();
		    session.close();
			return list1;
		}


		@Override
		public void register(Customer cust) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			
			
				session.save(cust);
				tx.commit();
			
		}


	


		


	


	

}
