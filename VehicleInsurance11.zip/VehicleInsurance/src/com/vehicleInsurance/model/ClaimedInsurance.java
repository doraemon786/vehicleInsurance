package com.vehicleInsurance.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ClaimedInsurance {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int claimid;
	private int insuranceId;
	private String mobile;
	private String reason;
	private int amount;
	private String currdate;
	private String status="Pending";
	
	public ClaimedInsurance() {
		super();
	}

	public int getClaimid() {
		return claimid;
	}

	public void setClaimid(int claimid) {
		this.claimid = claimid;
	}

	public int getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getcurrDate() {
		return currdate;
	}

	public void setcurrDate(String date) {
		this.currdate = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ClaimedInsurance(int claimid, int insuranceId, String mobile, String reason, int amount, String date,
			String status) {
		super();
		this.claimid = claimid;
		this.insuranceId = insuranceId;
		this.mobile = mobile;
		this.reason = reason;
		this.amount = amount;
		this.currdate = date;
		this.status = status;
	}

	@Override
	public String toString() {
		return "ClaimedInsurance [claimid=" + claimid + ", insuranceId=" + insuranceId + ", mobile=" + mobile
				+ ", reason=" + reason + ", amount=" + amount + ", date=" + currdate + ", status=" + status + "]";
	}

	
	
	
}
