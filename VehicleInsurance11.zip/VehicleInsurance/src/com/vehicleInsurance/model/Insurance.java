package com.vehicleInsurance.model;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;





@Entity
public class Insurance {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int insuranceId;
	private String vehicleType;
	private String manufacturer;
	private String model;
	private String dlNo;
	private String purchaseDate;
	private String registrationNumber;
	private String engineNo;
	private String chassisNo;
	private String yearofinsurance;
	private int amount;
	private String party;
	private int customerId;
	
	
	public Insurance() {
		super();
	}


	public int getInsuranceId() {
		return insuranceId;
	}


	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}


	public String getVehicleType() {
		return vehicleType;
	}


	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}


	public String getManufacturer() {
		return manufacturer;
	}


	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public String getDlNo() {
		return dlNo;
	}


	public void setDlNo(String dlNo) {
		this.dlNo = dlNo;
	}


	public String getPurchaseDate() {
		return purchaseDate;
	}


	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}


	public String getRegistrationNumber() {
		return registrationNumber;
	}


	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}


	public String getEngineNo() {
		return engineNo;
	}


	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}


	public String getChassisNo() {
		return chassisNo;
	}


	public void setChassisNo(String chassisNo) {
		this.chassisNo = chassisNo;
	}


	public String getYearofinsurance() {
		return yearofinsurance;
	}


	public void setYearofinsurance(String yearofinsurance) {
		this.yearofinsurance = yearofinsurance;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public String getParty() {
		return party;
	}


	public void setParty(String party) {
		this.party = party;
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public Insurance(int insuranceId, String vehicleType, String manufacturer, String model, String dlNo,
			String purchaseDate, String registrationNumber, String engineNo, String chassisNo, String yearofinsurance,
			int amount, String party, int customerId) {
		super();
		this.insuranceId = insuranceId;
		this.vehicleType = vehicleType;
		this.manufacturer = manufacturer;
		this.model = model;
		this.dlNo = dlNo;
		this.purchaseDate = purchaseDate;
		this.registrationNumber = registrationNumber;
		this.engineNo = engineNo;
		this.chassisNo = chassisNo;
		this.yearofinsurance = yearofinsurance;
		this.amount = amount;
		this.party = party;
		this.customerId = customerId;
	}


	@Override
	public String toString() {
		return "Insurance [insuranceId=" + insuranceId + ", vehicleType=" + vehicleType + ", manufacturer="
				+ manufacturer + ", model=" + model + ", dlNo=" + dlNo + ", purchaseDate=" + purchaseDate
				+ ", registrationNumber=" + registrationNumber + ", engineNo=" + engineNo + ", chassisNo=" + chassisNo
				+ ", yearofinsurance=" + yearofinsurance + ", amount=" + amount + ", party=" + party + ", customerId="
				+ customerId + "]";
	}




	
	
}
