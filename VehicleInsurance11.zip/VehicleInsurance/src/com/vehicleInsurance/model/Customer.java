package com.vehicleInsurance.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	private String name;
	private String age;
	private String email;
	private String mobile;
	private String income;
	private String occupation;
	private String username;
	private String password;
	
	public Customer() {
		super();
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Customer(int customerId, String name, String age, String email, String mobile, String income,
			String occupation, String username, String password) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.age = age;
		this.email = email;
		this.mobile = mobile;
		this.income = income;
		this.occupation = occupation;
		this.username = username;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", age=" + age + ", email=" + email
				+ ", mobile=" + mobile + ", income=" + income + ", occupation=" + occupation + ", username=" + username
				+ ", password=" + password + "]";
	}
	
/*	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Insurance>Insurance ;*/
	
	

	

}

	


