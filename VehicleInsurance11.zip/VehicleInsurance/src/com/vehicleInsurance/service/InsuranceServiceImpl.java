package com.vehicleInsurance.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicleInsurance.dao.InsuranceDaoImpl;
import com.vehicleInsurance.model.ClaimedInsurance;
import com.vehicleInsurance.model.Customer;
import com.vehicleInsurance.model.Insurance;

@Transactional
@Service
public class InsuranceServiceImpl implements  InsuranceService{

	
	@Autowired
	InsuranceDaoImpl  indao;
	
	@Override
	public Insurance buyInsurance(Insurance insurance) {
		
		return indao.buyInsurance(insurance);
	}

	@Override
	public int verifyUser(String username, String password) {
		
		return indao.verifyUser(username, password);
	}

	@Override
	public List<Customer> getCustomer(int userid) {
		// TODO Auto-generated method stub
		return indao.getCustomer(userid);
	}

	@Override
	public boolean claimInsurance(ClaimedInsurance claimins) {
		
		return indao.claimInsurance(claimins);
	}

	@Override
	public int verifyAdmin(String username, String password) {
		// TODO Auto-generated method stub
		return indao.verifyAdmin(username, password);
	}

	@Override
	public List<ClaimedInsurance> getPendingClaim() {
		// TODO Auto-generated method stub
		return indao.getPendingClaim();
	}

	@Override
	public List<Insurance> getInsurancedetails(int insuranceid) {
		// TODO Auto-generated method stub
		return indao.getInsurancedetails(insuranceid);
	}

	@Override
	public int setRequestStatusAccept(String insuranceid) {
		// TODO Auto-generated method stub
		return indao.setRequestStatusAccept(insuranceid);
	}

	@Override
	public int setRequestStatusReject(String insuranceid) {
		
		return indao.setRequestStatusReject(insuranceid);
	}

	@Override
	public List<ClaimedInsurance> claimHistory(int userid) {
		
		return indao.claimHistory(userid);
	}

	@Override
	public void register(Customer cust) {
		indao.register(cust);
		
	}



	
		
		
	





}
