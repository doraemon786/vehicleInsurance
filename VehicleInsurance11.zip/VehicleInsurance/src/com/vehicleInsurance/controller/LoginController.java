package com.vehicleInsurance.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vehicleInsurance.model.Customer;
import com.vehicleInsurance.model.Insurance;
import com.vehicleInsurance.service.InsuranceServiceImpl;


@Controller
public class LoginController {

	@Autowired
	InsuranceServiceImpl iser;
	@RequestMapping("/login")
	public String showLoginView(Model modal)
	{
		
		String view="loginpage";
		return view;
	}
	
	//calling service method to verify login
		@RequestMapping(value="/loginprocessing",method=RequestMethod.POST)
		public String LoginValidation(Model model,HttpServletRequest req,HttpSession s)
		{
			String username=req.getParameter("username");
			String password=req.getParameter("password");
			
			
			System.out.println("this is password "+password);					//debug code
			int userid=iser.verifyUser(username, password);
			List<Customer> cust=iser.getCustomer(userid);
			System.out.println("userid is......."+userid);
			model.addAttribute("name",cust.get(0).getName());
			s.setAttribute("customerid", userid);
			if(userid!=0)
			{
			return "Dashboard";
			}
			return "loginpage";
		}
		
		
		@RequestMapping("/registration")
		public String showRegistrationView(Model modal)
		{
			
			String view="registrationpage";
			modal.addAttribute("register", new Customer());
			return view;
		}
		
		@RequestMapping(value="/registerprocessing",method=RequestMethod.POST)
		public String registration(@Valid @ModelAttribute("register") 
		Customer cust ,BindingResult bindingResult,Model model,HttpServletRequest req,HttpSession session)
		{
			System.out.println(cust);
			String view="";
			if(bindingResult.hasErrors())
			{
				view="loginpage";
				return view;
			}
			else
			{
				iser.register(cust);
				
				
		//	Insurance insuran=inser.buyInsurance(insurance);
				return "plans";
		}
			
		}
}
