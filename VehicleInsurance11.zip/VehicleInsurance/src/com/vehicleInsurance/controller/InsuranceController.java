package com.vehicleInsurance.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vehicleInsurance.model.ClaimedInsurance;
import com.vehicleInsurance.model.Customer;
import com.vehicleInsurance.model.Insurance;
import com.vehicleInsurance.service.InsuranceServiceImpl;



@Controller
public class InsuranceController {

	
	@Autowired
	InsuranceServiceImpl inser;
	
	@RequestMapping("/buyInsurance")
	public String showLoginView(Model modal)
	{
		modal.addAttribute("Insurance", new InsuranceController());
		String view="buyInsurance";
		return view;
	}
	
	
	@RequestMapping(value="/buyInsuranceProcessing",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid @ModelAttribute("insurance") 
	Insurance insurance ,BindingResult bindingResult,Model model,HttpServletRequest req,HttpSession session)
	{
		System.out.println(insurance);
		String view="";
		if(bindingResult.hasErrors())
		{
			view="buyInsurance";
			return view;
		}
		else
		{
			session.setAttribute("cardetails", insurance);
			
	//	Insurance insuran=inser.buyInsurance(insurance);
			return "plans";
	}
		
	}
		
	
	
		@RequestMapping(value="/plansProcessing",method=RequestMethod.POST)
		public String validateregistrationPlans(Model model,HttpServletRequest req,HttpSession session)
		{
		int  amount=0;
		System.out.println("heloo.................");
				String party=req.getParameter("somedata");
				String Year=req.getParameter("year");
				String insuredamount=req.getParameter("insuredamount");
				
				
				int year=Integer.valueOf(Year);
				int amount_insurance=Integer.valueOf(insuredamount);
				
				System.out.println(party);
				System.out.println(Year);
				
				session.setAttribute("party", party);
				session.setAttribute("insuredyear", Year);
				session.setAttribute("amt", amount_insurance);
				
				if(year==1)
				{
					amount=amount_insurance/12;
				}
				if(year==2)
				{
					amount=amount_insurance/24;
				}
				if(year==3)
				{
					amount=amount_insurance/36;
				}
			session.setAttribute("premium", amount);
		//	Insurance insuran=inser.buyInsurance(insurance);
				return "payment";
		}
		
		
		
		
		
		
		
		
		
		
		
	@RequestMapping(value="/paymentprocessing",method=RequestMethod.POST)
		public String  paymentprocessing(Model model,HttpServletRequest req,HttpSession session)
		{
		Insurance insurance=(Insurance)session.getAttribute("cardetails");
	    String year=(String)session.getAttribute("insuredyear");
	    int amount=(int)session.getAttribute("amt");
	    String party=(String)session.getAttribute("party");
	    insurance.setYearofinsurance(year);
	    insurance.setAmount(amount);
	    insurance.setParty(party);
	    System.out.println("controller..........");
   int userid=(int) session.getAttribute("customerid");
	  System.out.println("jfbjhsfbaas.............asfsaf"+userid);
	  insurance.setCustomerId(userid);
	    System.out.println("jtxhxchg.... .......");
	    
	Insurance ins= inser.buyInsurance(insurance);
	model.addAttribute("id",ins.getInsuranceId());
	model.addAttribute("amt",ins.getAmount());
	model.addAttribute("year",ins.getYearofinsurance());
		System.out.println("inside out..."+insurance);
		
		return "Insurancesuccess";
	}
	
	
	
	
	@RequestMapping("/claimInsurance")
	public String claiminsurance(Model modal)
	{
		modal.addAttribute("claimedInsurance", new ClaimedInsurance());
		String view="claiminsurance";
		return view;
	}

	
	@RequestMapping(value="/claimInsuranceProcessing",method=RequestMethod.POST)
	public String  claimInsuranceProcessing(@Valid @ModelAttribute("claimedInsurance") 
	ClaimedInsurance claimins ,BindingResult bindingResult,Model model,HttpServletRequest req,HttpSession session)
	{
		System.out.println("inside claim request....");
		Date date1= new Date();
		/*
	int policynumber=Integer.valueOf(req.getParameter("policynumber"));
		String mobile=req.getParameter("mobilenumber");
		String reason=req.getParameter("reason");*/
		String date=date1.toLocaleString();
		
		List<Insurance> insurancedetails=inser.getInsurancedetails(claimins.getInsuranceId());
		int amount=insurancedetails.get(0).getAmount();
		claimins.setAmount(amount);
		claimins.setcurrDate(date);
		
		System.out.println(claimins);
		boolean flag=inser.claimInsurance(claimins);
		
		if(flag==true){
			return "success";
		}
		System.out.println("last of claim insurance");

		return "failure";
		
		
}
	
	
	@RequestMapping(value="/accept",method=RequestMethod.POST)
	public String acceptreject(Model modal,HttpServletRequest req)
	{
		
	String insuranceid=req.getParameter("signal");
//int ids=Integer.valueOf(insuranceid);
	System.out.println("...................."+insuranceid);
	inser.setRequestStatusAccept(insuranceid);
		String view="success";
		return view;
	}
	
	
	@RequestMapping(value="/reject",method=RequestMethod.POST)
	public String reject(Model modal,HttpServletRequest req)
	{
		
	String insuranceid=req.getParameter("signal");
//int ids=Integer.valueOf(insuranceid);
	System.out.println("...................."+insuranceid);
	inser.setRequestStatusReject(insuranceid);
		String view="success";
		return view;
	}
	
	
	
	
	
	@RequestMapping("/claimHistory")
	public String showClaimHistory(Model modal,HttpServletRequest req,HttpSession s)
	{
		int userid=(int)s.getAttribute("customerid");
		System.out.println("claim history user id............"+userid);
		List<ClaimedInsurance> list=inser.claimHistory(userid);	
		System.out.println(list);
		modal.addAttribute("claimdetail",list);
		String view="claimHistory";
		return view;
	}
	
	
	
	
	
	
	
	
	
	
}
	
	
	
	

