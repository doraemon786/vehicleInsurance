package com.vehicleInsurance.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vehicleInsurance.model.ClaimedInsurance;
import com.vehicleInsurance.model.Customer;
import com.vehicleInsurance.service.InsuranceServiceImpl;

@Controller
public class AdminController {
 int count;
	@Autowired
	InsuranceServiceImpl iser;
	
	@RequestMapping("/adminlogin")
	public String showLoginView(Model modal)
	{
		
		String view="AdminLogin";
		return view;
	}
	
	
	@RequestMapping(value="/adminloginprocessing",method=RequestMethod.POST)
	public String adminLoginValidation(Model model,HttpServletRequest req,HttpSession s)
	{
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		
		
		System.out.println("this is password "+password);					//debug code
		 count=iser.verifyAdmin(username, password);
		
		if(count==1)
		{
		return "AdminDashboard";
		}
		return "loginpage";
	}
	
	
	
	
	@RequestMapping("/InsuranceAcceptance")
	public String showInsuranceView(Model modal)
	{
		
		String view="PendingClaim";
		
		List<ClaimedInsurance> list=iser.getPendingClaim();
		System.out.println("ewrwwwwwwwwwwwwwwwwwwwwwwwwwww............."+list);
		modal.addAttribute("pendingclaims", list);
		return view;
	}
	
}
